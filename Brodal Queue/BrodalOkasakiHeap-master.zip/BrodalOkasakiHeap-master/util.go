package BrodalOkasakiHeap

import "fmt"


func printSpace(amount int) {
    for i:=0; i<amount; i++ {
        fmt.Print(" ")
    }
}