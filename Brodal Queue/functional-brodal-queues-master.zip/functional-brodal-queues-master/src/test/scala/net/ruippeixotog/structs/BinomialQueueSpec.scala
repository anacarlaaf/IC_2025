package net.ruippeixotog.structs

class BinomialQueueSpec extends PriorityQueueSpec[BinomialQueue] {
  def queueName = "binomial queue"
}