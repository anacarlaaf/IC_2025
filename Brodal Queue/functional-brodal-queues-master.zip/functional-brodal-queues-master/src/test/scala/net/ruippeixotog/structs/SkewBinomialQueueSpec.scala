package net.ruippeixotog.structs

class SkewBinomialQueueSpec extends PriorityQueueSpec[SkewBinomialQueue] {
  def queueName = "skew binomial queue"
}
